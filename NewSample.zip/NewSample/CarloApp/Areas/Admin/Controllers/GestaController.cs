using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CarloApp.Models;

namespace CarloApp.Areas_Admin_Controllers
{
    public class GestaController : Controller
    {
        private readonly gestagwapoContext _context;

        public GestaController(gestagwapoContext context)
        {
            _context = context;
        }

        // GET: Gesta
        public async Task<IActionResult> Index()
        {
            return View(await _context.Carlgests.ToListAsync());
        }

        // GET: Gesta/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carlgest = await _context.Carlgests
                .FirstOrDefaultAsync(m => m.Id == id);
            if (carlgest == null)
            {
                return NotFound();
            }

            return View(carlgest);
        }

        // GET: Gesta/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Gesta/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Product,Id,Category,Name,Units,Stock,Price,Status")] Carlgest carlgest)
        {
            if (ModelState.IsValid)
            {
                _context.Add(carlgest);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(carlgest);
        }

        // GET: Gesta/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carlgest = await _context.Carlgests.FindAsync(id);
            if (carlgest == null)
            {
                return NotFound();
            }
            return View(carlgest);
        }

        // POST: Gesta/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Product,Id,Category,Name,Units,Stock,Price,Status")] Carlgest carlgest)
        {
            if (id != carlgest.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carlgest);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarlgestExists(carlgest.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(carlgest);
        }

        // GET: Gesta/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carlgest = await _context.Carlgests
                .FirstOrDefaultAsync(m => m.Id == id);
            if (carlgest == null)
            {
                return NotFound();
            }

            return View(carlgest);
        }

        // POST: Gesta/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var carlgest = await _context.Carlgests.FindAsync(id);
            _context.Carlgests.Remove(carlgest);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarlgestExists(int id)
        {
            return _context.Carlgests.Any(e => e.Id == id);
        }
    }
}
