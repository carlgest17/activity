﻿using System;
using System.Collections.Generic;

namespace CarloApp.Models
{
    public partial class Carlgest
    {
        public string Product { get; set; }
        public int Id { get; set; }
        public string Category { get; set; }
        public string Name { get; set; }
        public string Units { get; set; }
        public string Stock { get; set; }
        public int Price { get; set; }
        public string Status { get; set; }
    }
}
